package sit.int202.classicmodelstue2.sevlet;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import sit.int202.classicmodelstue2.entities.Office;
import sit.int202.classicmodelstue2.repositories.OfficeRepository;

import java.io.IOException;

@WebServlet(name = "OfficeAddServlet", value = "/OfficeAdd")
public class OfficeAddServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        getServletContext().getRequestDispatcher("/add-office.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String newOfc = request.getParameter("newOfficeCode");
        String newCity = request.getParameter("newCity");
        String newAd1 = request.getParameter("newAddressLine1");
        String newCountry = request.getParameter("newCountry");
        String newPhone = request.getParameter("newPhone");
        String newPostal = request.getParameter("newPostal");
        String newTerritory = request.getParameter("newTerritory");

        OfficeRepository officeRepository = new OfficeRepository();
        Office existingOffice = officeRepository.find(newOfc);

        if(newOfc != null) {
            if (existingOffice != null && newOfc.equals(existingOffice.getOfficeCode())) {
                request.setAttribute("errorMessage", "Error: Failed to add. Office code already exists.");
            } else {
                Office addOffice = new Office();
                addOffice.setOfficeCode(newOfc);
                addOffice.setCountry(newCountry);
                addOffice.setCity(newCity);
                addOffice.setAddressLine1(newAd1);
                addOffice.setPhone(newPhone);
                addOffice.setPostalCode(newPostal);
                addOffice.setTerritory(newTerritory);
                officeRepository.insert(addOffice);
//                request.setAttribute("selectedOffice", addOffice);
            }
        }
        officeRepository.close();
        response.sendRedirect(request.getContextPath() + "/office-list");
    }
}

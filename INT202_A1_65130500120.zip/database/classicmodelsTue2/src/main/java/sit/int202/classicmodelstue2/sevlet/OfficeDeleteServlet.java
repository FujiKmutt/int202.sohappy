package sit.int202.classicmodelstue2.sevlet;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import sit.int202.classicmodelstue2.entities.Office;
import sit.int202.classicmodelstue2.repositories.OfficeRepository;

import java.io.IOException;
import java.util.List;

@WebServlet(name = "OfficeDeleteServlet", value = "/OfficeDelete")
public class OfficeDeleteServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String officeCode = request.getParameter("officeCode");
        request.setAttribute("officeCode",officeCode);
        getServletContext().getRequestDispatcher("/office-list.jsp").forward(request, response);
    }
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
       try {
           String officeCode = request.getParameter("officeCode");
           String yes = request.getParameter("yes");
           String no = request.getParameter("no");
           OfficeRepository officeRepository = new OfficeRepository();
           if(yes != null) {
               if (officeCode != null) {
                   Office existingOffice = officeRepository.find(officeCode);
                   if (existingOffice != null) {
                       if(officeRepository.delete(officeCode)){
                           response.sendRedirect(request.getContextPath() + "/office-list");
                       }
                   }
               }
           }else if(no != null){
               response.sendRedirect(request.getContextPath() + "/office-list");
           }
       } catch (Exception e) {
        request.setAttribute("message", "Error: Failed to delete. You need to delete FK first.");
        getServletContext().getRequestDispatcher("/office-list.jsp").forward(request, response);
    }

    }
}

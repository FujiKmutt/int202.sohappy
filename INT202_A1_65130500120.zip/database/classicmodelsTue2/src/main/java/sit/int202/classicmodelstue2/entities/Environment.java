package sit.int202.classicmodelstue2.entities;

public class Environment {
    public static final String PUNIT_NANME = "classic-models";
}

package sit.int202.classicmodelstue2.sevlet;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import sit.int202.classicmodelstue2.entities.Office;
import sit.int202.classicmodelstue2.repositories.OfficeRepository;

import java.io.IOException;
import java.util.List;

@WebServlet(name = "OfficeFindServlet", value = "/OfficeFind")
public class OfficeFindServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String CityOrCountry = request.getParameter("CityOrCountry");

        OfficeRepository officeRepository = new OfficeRepository();
        List<Office> findOffice = officeRepository.findByCityOrCountry(CityOrCountry);
        request.setAttribute("offices",findOffice);
        getServletContext().getRequestDispatcher("/office-list.jsp").forward(request, response);
    }
}

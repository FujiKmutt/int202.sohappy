package sit.int202.classicmodelstue2.sevlet;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import sit.int202.classicmodelstue2.entities.Office;
import sit.int202.classicmodelstue2.repositories.OfficeRepository;

import java.io.IOException;

@WebServlet(name = "OfficeEditServlet", value = "/OfficeEdit")
public class OfficeEditServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String officeCode = request.getParameter("officeCode");
        request.setAttribute("officeCode",officeCode);
        getServletContext().getRequestDispatcher("/update-office.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String officeCode = request.getParameter("officeCode");
        String newCity = request.getParameter("newCity");
        String newCountry = request.getParameter("newCountry");
        String newPhone = request.getParameter("newPhone");
        String newAd1 = request.getParameter("newAddressLine1");
        String newPostal = request.getParameter("newPostal");
        String newTerritory = request.getParameter("newTerritory");

        OfficeRepository officeRepository = new OfficeRepository();

        if (officeCode != null) {
            Office existingOffice = officeRepository.find(officeCode);
            if (existingOffice != null) {
                existingOffice.setOfficeCode(officeCode);
                existingOffice.setCity(newCity);
                existingOffice.setCountry(newCountry);
                existingOffice.setPhone(newPhone);
                existingOffice.setAddressLine1(newAd1);
                existingOffice.setPostalCode(newPostal);
                existingOffice.setTerritory(newTerritory);
                officeRepository.update(existingOffice);
            }
        }
        officeRepository.close();
       response.sendRedirect(request.getContextPath() + "/office-list");
    }
}